package com.tl666.service;


import com.tl666.dao.LoginDao;
import com.tl666.domain.Ruser;

public class LoginService {

	public Ruser login(String uname, String pwd) {
		LoginDao dao = new LoginDao();
		return dao.login(uname, pwd);
	}
}
