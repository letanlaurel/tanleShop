package com.tl666.service;

import java.util.List;
import java.util.NoSuchElementException;

import com.tl666.dao.GoodsDao;
import com.tl666.domain.Goods;
import com.tl666.domain.Gtype;

public class GoodsService {
	private GoodsDao g = new GoodsDao();
	public List<Goods> getAllGoodsService() throws Exception {
		 List<Goods> allGoods = g.getAllGoods();
		 if(allGoods != null) {
			 return allGoods;
		 }else {
			 throw new NoSuchElementException("没找到商品");
		 }
	}
	public List<Gtype> getAllGtypeService() throws Exception {
		 List<Gtype> allGtype = g.getAllGtype();
		 if(allGtype != null) {
			 return allGtype;
		 }else {
			 throw new NoSuchElementException("没找到分类");
		 }
	}

	public void delGoodsService(String id) throws Exception {
		g.delGoods(Integer.parseInt(id));
	}
	public Goods getGoodsService(String id) throws Exception {
		return g.getGoods(Integer.parseInt(id));
	}

	public void addGoodsService(Goods goods) throws Exception {
		g.AddGoods(goods);
	}

	public void updateGoodsService(Goods goods, String id) throws Exception {
		g.updateGoods(goods, Integer.parseInt(id));
	}
	
	
	public void delGtypeService(String id) throws Exception {
		g.delGtype(Integer.parseInt(id));
	}
	public Gtype getGtypeService(String id) throws Exception {
		return g.getGtype(Integer.parseInt(id));
	}

	public void addGtypeService(Gtype gtype) throws Exception {
		g.AddGtype(gtype);
	}

	public void updateGtypeService(Gtype gtype, String id) throws Exception {
		g.updateGtype(gtype, Integer.parseInt(id));
	}
}
