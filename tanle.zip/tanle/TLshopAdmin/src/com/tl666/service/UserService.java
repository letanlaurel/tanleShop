package com.tl666.service;

import java.util.List;
import java.util.NoSuchElementException;

import com.tl666.dao.UserDao;
import com.tl666.domain.Ruser;

public class UserService {
	private UserDao ud = new UserDao();

	public void addUserService(Ruser user) throws Exception {
		ud.addUser(user);
	}

	public void delUserService(String id) throws Exception {
		ud.delUser(Integer.parseInt(id));
	}

	public int updateUserService(Ruser user, String id,String str) throws Exception {
		return ud.updateUser(Integer.parseInt(id), str,user);
	}

	public List<Ruser> showAllUserService() throws Exception {
		List<Ruser> allUser = ud.showAllUser();
		if (allUser != null) {
			return allUser;
		} else {
			throw new NoSuchElementException("暂无用户");
		}
	}

}
