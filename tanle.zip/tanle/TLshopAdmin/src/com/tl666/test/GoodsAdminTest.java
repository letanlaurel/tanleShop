package com.tl666.test;


import com.tl666.dao.GoodsDao;
import com.tl666.dao.impl.IGoodsDao;
import com.tl666.domain.Goods;

public class GoodsAdminTest {
		public static void main(String[] args) throws Exception {
			IGoodsDao g = new GoodsDao();
			Goods goods = new Goods();
			goods.setName("华为手机");
			goods.setPrice(147.0);
			goods.setImg("goods_11.jpg");
			goods.setGdesc("这是一款好东西");
			goods.setIshot(1);
			goods.setCid(3);
			g.delGoods(9);
			System.out.println();
		}
}
