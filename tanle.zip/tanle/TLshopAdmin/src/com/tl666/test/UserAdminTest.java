package com.tl666.test;

import java.sql.SQLException;
import java.util.List;

import com.tl666.dao.UserDao;
import com.tl666.dao.impl.IUsersDao;
import com.tl666.domain.Ruser;

public class UserAdminTest {
	public static void main(String[] args) throws SQLException {
		IUsersDao u = new UserDao();
		List<Ruser> list = u.showAllUser();
		for (Ruser ruser : list) {
			System.out.println(ruser);
		}
	}
	
}
