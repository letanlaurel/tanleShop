package com.tl666.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.tl666.domain.Ruser;
import com.tl666.jdbc.Util.JDBCUtil;

public class LoginDao {

	public Ruser login(String uname, String pwd) {
		String sql = "select * from ruser where uname = ? and pwd = ?";
		QueryRunner qr = JDBCUtil.Queryrunner();
		Ruser user = null;
		try {
			 user = qr.query(sql, new BeanHandler<Ruser>(Ruser.class),uname,pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

}
