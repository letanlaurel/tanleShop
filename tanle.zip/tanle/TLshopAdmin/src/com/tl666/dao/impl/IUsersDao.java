package com.tl666.dao.impl;

import java.sql.SQLException;
import java.util.List;

import com.tl666.domain.Ruser;

public interface IUsersDao {
	/**
	 * 	 添加用户
	 * @throws SQLException 
	 */
	public void addUser(Ruser user) throws SQLException;
	/**
	 * 	 根据id删除用户
	 */
	public void delUser(int id)throws SQLException;
	/**
	 * 	 根据id修改密码
	 * @return 
	 */
	public int updateUser(int id, String str, Ruser user)throws SQLException;
	/**
	 * 	 显示所有用户
	 */
	public List<Ruser> showAllUser()throws SQLException;
}
