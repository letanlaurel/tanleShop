package com.tl666.dao.impl;

import java.sql.SQLException;
import java.util.List;

import com.tl666.domain.Goods;
import com.tl666.domain.Gtype;

public interface IGoodsDao {
	
	/*
	 * 添加商品
	 */
	public void AddGoods(Goods goods) throws SQLException;
	/*
	 *  根据ID删除商品
	 */
	public void delGoods(int id) throws SQLException;
	/*
	 *  根据ID修改商品
	 */
	public void updateGoods(Goods goods, int id) throws SQLException;
	/*
	 *  根据ID获取指定商品
	 */
	public Goods getGoods(int id) throws SQLException;
	/*
	 * 获取所有商品
	 */
	public List<Goods> getAllGoods() throws SQLException;
	
	
	
	
	
	
	/*
	 * 	获取所有分类
	 */
	public List<Gtype> getAllGtype() throws SQLException;
	/*
	 *  根据ID获取指定分类
	 */
	public Gtype getGtype(int id) throws SQLException;
	/*
	 *  根据ID修改分类
	 */
	public void updateGtype(Gtype gtype, int id) throws SQLException;
	/*
	 *  根据ID删除分类
	 */
	public void delGtype(int id) throws SQLException;
	/*
	 * 添加分类
	 */
	public void AddGtype(Gtype gtype) throws SQLException;
	
}
