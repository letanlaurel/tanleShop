package com.tl666.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.tl666.dao.impl.IUsersDao;
import com.tl666.domain.Ruser;
import com.tl666.jdbc.Util.JDBCUtil;

public class UserDao implements IUsersDao {
	private QueryRunner qr = JDBCUtil.Queryrunner();

	@Override
	public void addUser(Ruser user) throws SQLException {
		String sql = "INSERT INTO ruser (uname,pwd,name) VALUE(?,?,?)";
		qr.update(sql, user.getUname(), user.getPwd(), user.getName());
	}

	@Override
	public void delUser(int id) throws SQLException {
		String sql = "delete from ruser where id=?";
		qr.update(sql,id);
	}

	@Override
	public int updateUser(int id,String str, Ruser user) throws SQLException {
		String sql = "update ruser set pwd=?,name=? where id=?&&pwd=?";
		return qr.update(sql,user.getPwd(),user.getName(),id,str);
	}

	@Override
	public List<Ruser> showAllUser() throws SQLException {
		String sql = "select * from ruser";
		return qr.query(sql, new BeanListHandler<Ruser>(Ruser.class));
	}

}
