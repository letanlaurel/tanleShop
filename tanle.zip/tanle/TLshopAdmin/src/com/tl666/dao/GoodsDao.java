package com.tl666.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.tl666.dao.impl.IGoodsDao;
import com.tl666.domain.Goods;
import com.tl666.domain.Gtype;
import com.tl666.jdbc.Util.JDBCUtil;

public class GoodsDao implements IGoodsDao {
		 private QueryRunner qr = JDBCUtil.Queryrunner();
	
	@Override
	public void AddGoods(Goods goods) throws SQLException {
		String sql = "insert into goods (name,price,img,gdesc,ishot,cid) value(?,?,?,?,?,?)";
		qr.update(sql, goods.getName(),goods.getPrice(),goods.getImg(),goods.getGdesc(),goods.getIshot(),goods.getCid());
		
	}

	@Override
	public void delGoods(int id) throws SQLException {
		String sql = "delete from goods where id=?";
		qr.update(sql,id);
	}

	@Override
	public void updateGoods(Goods goods, int id) throws SQLException {
		String sql = "update goods set name=?,price=?,img=?,gdesc=?,ishot=?,cid=? where id=?";
		qr.update(sql,goods.getName(),goods.getPrice(),goods.getImg(),goods.getGdesc(),goods.getIshot(),goods.getCid(),id);
		
	}

	@Override
	public List<Goods> getAllGoods() throws SQLException {
		String sql = "select * from goods";
		return qr.query(sql, new BeanListHandler<Goods>(Goods.class));
		
	}

	@Override
	public Goods getGoods(int id) throws SQLException {
		String sql = "select * from goods where id=?";
		return qr.query(sql, new BeanHandler<Goods>(Goods.class), id);

	}

	@Override
	public List<Gtype> getAllGtype() throws SQLException {
		String sql = "select * from gtype";
		return qr.query(sql, new BeanListHandler<Gtype>(Gtype.class));
	}

	@Override
	public Gtype getGtype(int id) throws SQLException {
		String sql = "select * from gtype where cid=?";
		return qr.query(sql, new BeanHandler<Gtype>(Gtype.class), id);
	}

	@Override
	public void updateGtype(Gtype gtype, int id) throws SQLException {
		String sql = "update gtype set name=? where cid=?";
		qr.update(sql,gtype.getName(),id);
		
	}

	@Override
	public void delGtype(int id) throws SQLException {
		String sql = "delete from gtype where cid=?";
		qr.update(sql,id);
	}

	@Override
	public void AddGtype(Gtype gtype) throws SQLException {
		String sql = "insert into gtype (name) value(?)";
		qr.update(sql, gtype.getName());
	}

}
