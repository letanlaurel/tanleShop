package com.tl666.domain;

public class Gtype {
	private Integer cid;
	private String name;
	
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Gtpye [cid=" + cid + ", name=" + name + "]";
	}
	
}
