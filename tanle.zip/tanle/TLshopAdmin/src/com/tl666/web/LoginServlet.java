package com.tl666.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tl666.domain.Ruser;
import com.tl666.service.LoginService;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		String uname = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		LoginService service = new LoginService();
		Ruser user = service.login(uname,pwd);
		if(user != null) {
			request.getSession().setAttribute("user", user);
			response.setHeader("refresh","0.3;url="+request.getContextPath()+"/admin_index.jsp");
		}else {
			request.setAttribute("login", "账号或密码错误");
			request.getRequestDispatcher("admin_login.jsp").forward(request, response);
		}
		
	}

}
