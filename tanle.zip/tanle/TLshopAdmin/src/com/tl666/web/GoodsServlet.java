package com.tl666.web;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tl666.domain.Goods;
import com.tl666.domain.Gtype;
import com.tl666.service.GoodsService;

/**
 * 从数据库获取商品数据 Servlet implementation class GoodsServlet
 */
@WebServlet("/GoodsServlet")
public class GoodsServlet extends TLServlet {
	private static final long serialVersionUID = 1L;
	private GoodsService gs = new GoodsService();

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected String addGoods(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<Gtype> allGtype = gs.getAllGtypeService();
			request.setAttribute("allGtype", allGtype);
			String str1 = request.getParameter("name");
			String str6 = request.getParameter("gdesc");
			if (str1 != null && str6 != null) {
				str1 = new String(str1.getBytes("iso-8859-1"), "utf-8");
				str6 = new String(str6.getBytes("iso-8859-1"), "utf-8");
			}
			String str2 = request.getParameter("price");
			String str3 = request.getParameter("cid");
			String str4 = request.getParameter("ishot");
			// String str5 = request.getParameter("img");
			Goods goods = new Goods();
			if (str3 == null || str2 == null || str4 == null) {
				return "edit.jsp";
			} else {
				goods.setName(str1);
				goods.setCid(Integer.parseInt(str3));
				goods.setPrice(Double.parseDouble(str2));
				goods.setGdesc(str6);
				goods.setIshot(Integer.parseInt(str4));
				goods.setImg("xiaomi.jpg");
				gs.addGoodsService(goods);
				return "GoodsServlet?action=getAllGoods";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	protected String delGoods(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String id = request.getParameter("id");
			System.out.println(id);
			gs.delGoodsService(id);
			return "/GoodsServlet?action=getAllGoods";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	protected String getAllGoods(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<Goods> allGoods = gs.getAllGoodsService();
			Collections.reverse(allGoods);
			request.setAttribute("allGoods", allGoods);
			return "main.jsp";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	protected String getGoods(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<Gtype> allGtype = gs.getAllGtypeService();
			request.setAttribute("allGtype", allGtype);
			String id = request.getParameter("id");
			Goods goods2 = gs.getGoodsService(id);
			request.setAttribute("goods2", goods2);
			return "updateGoods.jsp?st=" + id;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	protected String updateGoods(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String id = request.getParameter("id");
			String str1 = request.getParameter("name");
			String str6 = request.getParameter("gdesc");
			if (str1 != null && str6 != null) {
				str1 = new String(str1.getBytes("iso-8859-1"), "utf-8");
				str6 = new String(str6.getBytes("iso-8859-1"), "utf-8");

			}
			String str2 = request.getParameter("price");
			String str4 = request.getParameter("ishot");
			String str3 = request.getParameter("cid");
			Goods goods = new Goods();
			goods.setName(str1);
			goods.setCid(Integer.parseInt(str3));
			goods.setPrice(Double.parseDouble(str2));
			goods.setGdesc(str6);
			goods.setIshot(Integer.parseInt(str4));
			goods.setImg("xiaomi.jpg");
			gs.updateGoodsService(goods, id);
			return "/GoodsServlet?action=getAllGoods";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	protected String getAllGtype(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<Gtype> allGtype = gs.getAllGtypeService();
			Collections.reverse(allGtype);
			request.setAttribute("allGtype", allGtype);
			return "category.jsp";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	protected String addGtype(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String str1 = request.getParameter("name");

			if (str1 != null) {
				str1 = new String(str1.getBytes("iso-8859-1"), "utf-8");
			}
			Gtype gtype = new Gtype();
			gtype.setName(str1);
			gs.addGtypeService(gtype);
			return "GoodsServlet?action=getAllGtype";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	protected String delGtype(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String id = request.getParameter("id");
			gs.delGtypeService(id);
			return "/GoodsServlet?action=getAllGtype";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	protected String getGtype(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<Gtype> allGtype = gs.getAllGtypeService();
			Collections.reverse(allGtype);
			request.setAttribute("allGtype", allGtype);
			String id = request.getParameter("id");
			if(id != null) {
			Gtype gtype2 = gs.getGtypeService(id);
			request.setAttribute("gtype2", gtype2);
			return "category2.jsp?st=" + id;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	protected String updateGtype(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String id = request.getParameter("id");
			String str1 = request.getParameter("name");
			if (str1 != null) {
				str1 = new String(str1.getBytes("iso-8859-1"), "utf-8");
			}
			Gtype gtype = new Gtype();
			gtype.setName(str1);
			gs.updateGtypeService(gtype, id);
			return "/GoodsServlet?action=getAllGtype";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
