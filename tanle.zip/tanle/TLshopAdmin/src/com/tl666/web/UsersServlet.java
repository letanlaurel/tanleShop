package com.tl666.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tl666.domain.Ruser;
import com.tl666.service.UserService;

/**
 * Servlet implementation class UsersServlet
 */
@WebServlet("/UsersServlet")
public class UsersServlet extends TLServlet {
	private static final long serialVersionUID = 1L;
	private UserService us = new UserService();

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected String addUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String str1 = request.getParameter("uname");
		String str2 = request.getParameter("pwd");
		Ruser user = new Ruser();
		user.setUname(str1);
		user.setPwd(str2);
		user.setName(str1);
		try {
			us.addUserService(user);
			return "/UsersServlet?action=showAllUser";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	protected String showAllUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<Ruser> allUser = us.showAllUserService();
			request.getSession().setAttribute("allUser", allUser);
			return "account.jsp";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	protected String delUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String id = request.getParameter("id");
			if(id.equals("1")) {
				request.setAttribute("lgg", "大胆！,你竟然敢移除你乐歌歌的账号!!");
			}else {
			us.delUserService(id);
			}
			return "/UsersServlet?action=showAllUser";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	protected String updateUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		try {
			String id = request.getParameter("id");
			Ruser user = new Ruser();
			String str1 = new String(request.getParameter("name").getBytes("iso-8859-1"), "utf-8");
			String str2 = request.getParameter("pwd");
			String str3 = request.getParameter("pwd2");
			System.out.println(str1);
			user.setName(str1);
			user.setPwd(str3);
			int updateU = us.updateUserService(user, id,str2);
			System.out.println(updateU);
			if(updateU == 1) {
				response.setHeader("refresh","0.1;url="+request.getContextPath()+"/updateu.jsp");
				
			}else {
				response.setHeader("refresh","0.1;url="+request.getContextPath()+"/updater.jsp");
				//response.setHeader("refresh","0.1;url="+request.getContextPath()+"/account2.jsp");
			}
			//response.setHeader("refresh","1;url="+request.getContextPath()+"/account2.jsp");
			return "/UsersServlet?action=showAllUser";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
