package com.tl666.service;

import com.tl666.dao.LoginDao;
import com.tl666.domain.User;

public class LoginService {

	public User login(String uname, String pwd) {
		LoginDao dao = new LoginDao();
		return dao.login(uname, pwd);
	}

}
