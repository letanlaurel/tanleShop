package com.tl666.service;

import com.tl666.dao.addUserDao;

public class UserService {

	public int setUserService(String... str ) {
		addUserDao user = new addUserDao();
		return user.setUserDao(str);
	}

	

}
