package com.tl666.service;

import java.util.List;

import com.tl666.dao.GoodsDao;
import com.tl666.domain.Goods;

public class GoodsService {

	public List<Goods> FindallgoodsService() {
		return GoodsDao.FindallgoodsDao();
	}
	
}
