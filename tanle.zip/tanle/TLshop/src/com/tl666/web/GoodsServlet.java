package com.tl666.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tl666.domain.Goods;
import com.tl666.service.GoodsService;

/**
 * 从数据库获取商品数据
 * Servlet implementation class GoodsServlet
 */
@WebServlet("/GoodsServlet")
public class GoodsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GoodsService goodsService = new GoodsService();
		List<Goods> allgoods = goodsService.FindallgoodsService();
		request.setAttribute("allgoods", allgoods);
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}

}
