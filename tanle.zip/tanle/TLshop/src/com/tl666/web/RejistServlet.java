package com.tl666.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tl666.service.UserService;

/**
 * Servlet implementation class RejistServlet
 */
@WebServlet("/RejistServlet")
public class RejistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String path = request.getContextPath();
			String str = request.getParameter("code");
			//System.out.println(str);
			String word = (String)request.getSession().getAttribute("checkcode_session");
			System.out.println(word);
			String str2 = request.getParameter("uname");
			String str3 = request.getParameter("pwd");
			String str5 = request.getParameter("phone");
			UserService u = new UserService();
			int i = u.setUserService(str2,str3,str5);
			if(word.equalsIgnoreCase(str)) {//不区分大小写
				if(i != 0) {
					response.getWriter().write("注册成功!!");
					response.setHeader("refresh","1;url="+path+"/login.jsp");
				}else {
					response.getWriter().write("注册失败!!");
					response.setHeader("refresh","1;url="+path+"/zhuche.jsp");
				}
			}else {
				response.getWriter().write("验证码错误！");
				response.setHeader("refresh","1;url="+path+"/zhuche.jsp");
			}
			
	}

}
