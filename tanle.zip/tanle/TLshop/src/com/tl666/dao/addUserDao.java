package com.tl666.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import com.tl666.jdbc.Util.JDBCUtil;

public class addUserDao {

	public int setUserDao(String... str) {
		String sql = "INSERT INTO user (uname,pwd,phone,name) VALUE(?,?,?,?);";
		QueryRunner qr = JDBCUtil.Queryrunner();
		int i = -1;
		try {
			 i = qr.update(sql, str[0],str[1],str[2],str[0]);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
		
}
