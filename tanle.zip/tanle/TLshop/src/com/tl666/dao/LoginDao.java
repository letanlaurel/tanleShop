package com.tl666.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.tl666.domain.User;
import com.tl666.jdbc.Util.JDBCUtil;

public class LoginDao {

	public User login(String uname, String pwd) {
		String sql = "select * from user where uname = ? and pwd = ?";
		QueryRunner qr = JDBCUtil.Queryrunner();
		User user = null;
		try {
			 user = qr.query(sql, new BeanHandler<User>(User.class),uname,pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

}
