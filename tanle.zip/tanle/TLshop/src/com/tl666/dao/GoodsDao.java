package com.tl666.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.tl666.domain.Goods;
import com.tl666.jdbc.Util.JDBCUtil;

public class GoodsDao {

	public static List<Goods> FindallgoodsDao() {
		String sql = "select * from goods";
		QueryRunner qr = JDBCUtil.Queryrunner();
		List<Goods> allgoods = null;
		try {
			 allgoods = qr.query(sql,new BeanListHandler<Goods>(Goods.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return allgoods;
	}
		
}
