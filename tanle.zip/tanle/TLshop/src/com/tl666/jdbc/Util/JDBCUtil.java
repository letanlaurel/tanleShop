package com.tl666.jdbc.Util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;

import com.alibaba.druid.pool.DruidDataSourceFactory;

/**
 *	 工具类
 * @author 1976087502
 *?rewriteBatchedStatements=true
 */
public class JDBCUtil {
	private JDBCUtil() {
	}
	public static DataSource dataSource= null;
	static {
		// 当类被加载到jvm的时候 静态代码块只会被执行一次 不能放到成员属性前
		try {
				// 1.加载配置文件
			Properties properties = new Properties();
			String path = JDBCUtil.class.getClassLoader().getResource("db.properties").getPath();//通过类加载器来获取目录
			FileInputStream finStream = new FileInputStream(path);
			properties.load(finStream);
			//连接池
		//	dataSource = BasicDataSourceFactory.createDataSource(properties);
			dataSource = DruidDataSourceFactory.createDataSource(properties);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 	调用apache公司的jar包中的方法获取连接
	 * @return
	 */
	public static QueryRunner Queryrunner() {
		QueryRunner qr = new QueryRunner(dataSource);//传入一个连接池
		return qr;
	}
	public static Connection getConn() {
		Connection connection = null;
		try {
			// 2.建立连接
			connection = dataSource.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	/**
	 * 释放资源的方法
	 */
	public static void close(Connection connection, Statement statement, ResultSet executeQuery) {
		// 5.关闭资源
			if (executeQuery != null) {
			try {
				executeQuery.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
