package com.tl666.code;

import java.util.Random;
/**
 * 生成随机4个验证码
 * @author 19760
 *
 */
public class RandomText {

	public static void main(String[] args) {
		String str = "QWERTYUIOPASDFGHJKLZXCVBNMzxcvbnmasdfghjklqwertyuiop0123456789";
		Random r = new Random();
		
		
		while(true) {
			StringBuffer strb = new StringBuffer();
		for (int i = 0; i < 4; i++) {
			int t = r.nextInt(62);
			strb.append(str.substring(t,t+1));
		}
		System.out.println(strb);
	}
	}

}
